if __name__ == "__main__":
        from ultralytics import YOLO
        import os
        os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
        try:
            model = YOLO("yolov8n-cls.pt", task="classify")
            model.train(
                **{'data': '/home/snuailab/datasets/mnist_cls/exports/ULTRALYTICS', 'epochs': 150, 'batch': 64, 'imgsz': [224, 224], 'lr0': 0.01, 'lrf': 0.01, 'rect': False, 'device': '0', 'workers': 2, 'seed': 0, 'verbose': True, 'project': 'hubs/mnist_cls', 'name': 'artifacts'}
            )
        except Exception as e:
            print(e)
            raise e
        