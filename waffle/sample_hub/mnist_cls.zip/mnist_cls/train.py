if __name__ == "__main__":
        from ultralytics import YOLO
        try:
            model = YOLO("yolov8n-cls.pt", task="classify")
            model.train(
                **{'data': '/home/lhj/ws/waffle_mukbang/datasets/mnist_cls/exports/YOLO', 'epochs': 50, 'batch': 512, 'imgsz': [224, 224], 'lr0': 0.01, 'lrf': 0.01, 'rect': False, 'device': '0', 'workers': 2, 'seed': 0, 'verbose': True, 'project': 'hubs/mnist_cls', 'name': 'artifacts'}
            )
        except Exception as e:
            print(e)
            raise e
        